1. make sure AMPPS is up and running (backend will connect to it) 
1. clone the repository: `git clone https://github.com/kauffmanes/infsci-2710-project.git`
2. install backend: cd backend then npm install
3. install frontend: cd client then npm install
4. install yarn -> https://yarnpkg.com/lang/en/docs/install/#debian-stable
5. to start backend: cd backend then yarn start
5. to build frontend: cd client yarn start
6. localhost:3000 will automatically open in browser 

google doc for drafting structure: https://docs.google.com/document/d/1JVpZHYpeQsk6zc3esfgODTGpUzecoJ-6rSoqZdDxqRA/edit?usp=sharing
