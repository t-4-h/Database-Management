import React from 'react';

const Layout = (props) => (
	<div className='o-layout'>
		{props.children}
	</div>
);

export default Layout;